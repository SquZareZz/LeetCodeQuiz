﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QuizSolution.Medium
{
    public class WordSearch
    {
        public bool Exist(char[][] board, string word)
        {
            var ListWord=new List<int>();
            int RowLen=board[0].Length;
            int i = 0;
            foreach(var WordPart in word)
            {
               
            }
            
            return true;

        }
    }
}

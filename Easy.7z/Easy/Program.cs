﻿using QuizSolution;
using QuizSolution.Easy;
using QuizSolution.Medium;
using System;
using static QuizSolution.Easy.SolutionMergeTwoLists;

int[] A = { 1, 2, 3, 1, 1 };
int[] B = { 10000 };
string[] ZZ = { "5", "2", "C", "D", "+" };
string[] Z = { "leet", "code" };
var C = "leetcode";
var D = 3;
int[][] DD = { new[] {0  }  };
int[][] E =
{
    new [] {1,3,1},
    new [] {1,0,0},
    new [] { 4, 2, 1 }
    //new [] {15,18}
};
int[] F = new[] {0 };
char[] E2 = { 'a' };
//, 'b', 'b', 'b','b', 'b', 'b', 'b', 'b', 'b', 'b', 'b', 'b'
//char[][] Board =
//{new []{'.', '.', '.', '.','9', '.', '.','5','.'},
//new []{ '.','4', '.','1', '.', '.', '.', '.', '.'},
//new []{ '.', '.', '.', '.', '.','3', '.', '.','1'},
//new []{'8', '.', '.', '.', '.', '.','.','2','.'},
//new []{ '.', '.','2', '.','7', '.', '.', '.', '.'},
//new []{ '.','1','5', '.', '.', '.', '.', '.', '.'},
//new []{ '.', '.', '.', '.', '.', '2','.', '.', '.'},
//new []{ '.','2', '.', '9','.', '.', '.', '.', '.' },
//new []{ '.', '.','4', '.', '.', '.', '.', '.', '.' } };
//new SetMatrixZeroes().SetZeroes2(E);
Console.WriteLine(new WordBreak().WordBreak1Fail(C,Z.ToList()));
Console.ReadLine();


